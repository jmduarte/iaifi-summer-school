//Numpy array shape [5]
//Min -0.102692782879
//Max 0.118463508785
//Number of zeros 0

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
output_bias_t b11[5];
#else
output_bias_t b11[5] = {-0.001935, 0.044482, -0.017264, -0.102693, 0.118464};
#endif

#endif
