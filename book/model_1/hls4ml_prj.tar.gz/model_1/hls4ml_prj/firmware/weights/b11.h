//Numpy array shape [5]
//Min -0.139161720872
//Max 0.062349751592
//Number of zeros 0

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
model_default_t b11[5];
#else
model_default_t b11[5] = {-0.1391617208719, 0.0581277571619, 0.0623497515917, 0.0130106518045, -0.0059641064145};
#endif

#endif
