//Numpy array shape [5]
//Min -0.139161720872
//Max 0.062349751592
//Number of zeros 0

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
output_bias_t b11[5];
#else
output_bias_t b11[5] = {-0.139162, 0.058128, 0.062350, 0.013011, -0.005964};
#endif

#endif
